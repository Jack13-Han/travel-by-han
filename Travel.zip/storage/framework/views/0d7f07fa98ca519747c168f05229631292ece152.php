<?php $__env->startSection('title'); ?>
    Create New Post : <?php echo e(env('APP_NAME')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">


                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3>Create New Post</h3>

                    <p class="mb-0">
                        <i class="fas fa-calendar text-primary"></i>
                        <?php echo e(date('d M Y')); ?>

                    </p>
                </div>

                <form action="<?php echo e(route('post.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-floating mb-4">
                        <input type="text" value="<?php echo e(old('title')); ?>" class="form-control <?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" id="postTitle" placeholder="Enter Your Post Title">
                        <label for="postTitle">Post Title</label>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback ps-3">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="mb-4">
                        <img src="<?php echo e(asset('image-default.png')); ?>" id="coverPreview" class="cover-img w-100 rounded-3 <?php $__errorArgs = ["cover"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" alt="">
                        <input type="file" accept="image/png,image/jpeg" name="cover" class="d-none" id="cover">
                        <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback ps-3">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-floating mb-4">
                        <textarea class="form-control <?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="description" style="height: 200px;" placeholder="Leave a comment here" id="floatingTextarea"><?php echo e(old('description')); ?></textarea>
                        <label for="floatingTextarea">Share Your Experience</label>

                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback ps-3">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="text-center mb-4">
                        <button class="btn btn-lg btn-primary ">
                            <i class="fas fa-message"></i>
                            Create Post
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        let coverPreview = document.querySelector("#coverPreview");
        let cover =document.querySelector('#cover');

        coverPreview.addEventListener('click',function(){
            cover.click();

        });

        cover.addEventListener('change',function(){
            let reader = new FileReader();

            reader.onload  = function (){
              coverPreview.src = reader.result;
            };
            reader.readAsDataURL(cover.files[0]);
            // console.log(cover.file);
        });

    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolar/Desktop/MMS IT(Web Development)/Laravel/the-explorer-laravel/resources/views/post/create.blade.php ENDPATH**/ ?>