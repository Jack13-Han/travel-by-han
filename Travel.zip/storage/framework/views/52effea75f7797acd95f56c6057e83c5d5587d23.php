<?php $__env->startSection('content'); ?>



    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">

                <div class="post mb-4">
                    <div class="row">

                        <h3 class="fw-bolder text-capitalize mb-4"><?php echo e($post->title); ?></h3>

                        <img src="<?php echo e(asset("storage/cover/".$post->cover)); ?>" class="cover-img w-100 rounded-3 mb-4" alt="">

                        <p class="text-black-50 mb-4 post-detail">
                            <?php echo e($post->description); ?>

                        </p>

                        <?php if($post->galleries->count()): ?>
                            <div class="gallery rounded border p-2 mb-4 ">
                                <h3 class="text-center fw-bolder mb-4">Post Gallery</h3>
                                <div class="row g-3 justify-content-center">
                                    <?php $__currentLoopData = $post->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-lg-3 col-md-4 ">
                                        <a class="venobox" data-gall="gallery" href="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>">
                                            <img src="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>" class="rounded gallery-photo" alt="image alt"/>
                                        </a>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="mb-4">
                            <h3 class="text-center fw-bolder ">Users Comment</h3>
                        </div>

                        <div class="row justify-content-center mb-4">
                            <div class="col-lg-8">

                                <div class="comments">
                                    <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                   <div class="border rounded mb-3 p-3">
                                          <div class="d-flex justify-content-between align-items-center mb-3">
                                              <div class="d-flex ">
                                                  <img src="<?php echo e(asset($comment->user->photo)); ?>" class="rounded-circle shadow-sm border border-white" height="38" alt="">
                                                  <p class="mb-0 ms-2  small">
                                                      <?php echo e($comment->user->name); ?>

                                                      <br>
                                                      <i class="fas fa-calendar text-primary"></i>
                                                      <?php echo e($comment->created_at->diffForHumans()); ?>

                                                  </p>
                                              </div>

                                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$comment)): ?>
                                                  <form action="<?php echo e(route('comment.destroy',$comment->id)); ?>" method="post">
                                                      <?php echo csrf_field(); ?>
                                                      <?php echo method_field('delete'); ?>
                                                      <button class="btn btn-sm btn-outline-danger">
                                                          <i class="fas fa-trash-alt"></i>
                                                      </button>
                                                  </form>
                                              <?php endif; ?>

                                          </div>

                                           <p class="mb-0">
                                               <?php echo e($comment->message); ?>

                                           </p>

                                   </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p class="text-center">
                                            There is no Comment yet !
                                            <?php if(auth()->guard()->check()): ?>
                                                Start comment now.
                                            <?php endif; ?>
                                            <?php if(auth()->guard()->guest()): ?>
                                                <a href="<?php echo e(route('login')); ?>">Login</a> to comment
                                            <?php endif; ?>
                                        </p>

                                    <?php endif; ?>
                                </div>


                                <?php if(auth()->guard()->check()): ?>

                                <form action="<?php echo e(route('comment.store')); ?>" method="post" id="comment-create">

                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                    <div class="form-floating mb-2">
                                        <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="message" style="height: 150px" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                                        <label for="floatingTextarea">Comments</label>

                                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback ps-3">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="text-center">
                                        <button class="btn btn-primary">Comment</button>
                                    </div>

                                </form>

                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center border rounded p-4">
                            <div class="d-flex ">
                                <img src="<?php echo e(asset($post->user->photo)); ?>" class="rounded-circle shadow-sm border border-white" height="38" alt="">
                                <p class="mb-0 ms-2  small">
                                    <?php echo e($post->user->name); ?>

                                    <br>
                                    <i class="fas fa-calendar text-primary"></i>
                                    <?php echo e($post->created_at->format('d-M-Y')); ?>

                                </p>
                            </div>



                            <div class="">

                                <?php if(auth()->guard()->check()): ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$post)): ?>
                                       <form action="<?php echo e(route('post.destroy',$post->id)); ?>" class="d-inline-block" method="post">
                                           <?php echo csrf_field(); ?>
                                           <?php echo method_field('delete'); ?>

                                           <button class="btn btn-outline-danger">
                                               <i class="fas fa-trash-alt fa-fw"></i>
                                           </button>

                                       </form>

                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>

                                            <a href="<?php echo e(route('post.edit',$post->id)); ?>" class="btn btn-outline-warning">
                                                <i class="fas fa-edit fa-fw"></i>
                                            </a>
                                        <?php endif; ?>

                                <?php endif; ?>

                                <a href="<?php echo e(route('index')); ?>" class="btn btn-outline-primary">Read All</a>
                            </div>

                        </div>

                    </div>
                </div>


            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolar/Desktop/MMS IT(Web Development)/Laravel/the-explorer-laravel/resources/views/post/detail.blade.php ENDPATH**/ ?>