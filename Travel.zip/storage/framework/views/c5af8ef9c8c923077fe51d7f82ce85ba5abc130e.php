<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/nicolar/Desktop/MMS IT(Web Development)/Laravel/the-explorer-laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>