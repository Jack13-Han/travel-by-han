<?php $__env->startSection('title'); ?>
    Edit Post : <?php echo e(env('APP_NAME')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">


                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3>Edit Post</h3>

                    <p class="mb-0">
                        <i class="fas fa-calendar text-primary"></i>
                        <?php echo e(date('d M Y')); ?>

                    </p>
                </div>



                <form action="<?php echo e(route('post.update',$post->id)); ?>" id="post-create" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-floating mb-4">
                        <input type="text" value="<?php echo e(old('title',$post->title)); ?>" class="form-control <?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>border border-danger is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" id="postTitle" placeholder="Enter Your Post Title">
                        <label for="postTitle">Post Title</label>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="mb-4">
                        <img src="<?php echo e(asset('storage/cover/'.$post->cover)); ?>" id="coverPreview" class="cover-img w-100 rounded-3 <?php $__errorArgs = ["cover"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>border border-danger is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" alt="">
                        <input type="file" name="cover" accept="image/png,image/jpeg" class="d-none" id="cover">
                        <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-floating mb-4">
                        <textarea class="form-control <?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>border border-danger is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="description" style="height: 200px;" placeholder="Leave a comment here" id="floatingTextarea"><?php echo e(old('description',$post->description)); ?></textarea>
                        <label for="floatingTextarea">Share Your Experience</label>

                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </form>


                <div class="border rounded p-3 mb-4" id="gallery">

                   <div class="d-flex align-items-stretch">
                       <div class="border px-5 rounded-2 me-2 d-flex justify-content-center align-items-center" id="upload-ui" style="height: 150px">
                           <i class="fas fa-upload fa-fw"></i>
                       </div>

                       <div class=" d-flex overflow-scroll" style="height: 150px">

                         <?php $__currentLoopData = $post->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <div class="d-flex me-2 align-items-end">
                                   <img src="<?php echo e(asset('storage/gallery/'.$g->photo)); ?>" class="h-100 rounded "  alt="">
                                   <form action="<?php echo e(route('gallery.destroy',$g->id)); ?>" method="post">
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field('delete'); ?>

                                       <button class="btn btn-sm btn-danger gallery-img-delete">
                                           <i class="fas fa-trash-alt"></i>
                                       </button>
                                   </form>
                               </div>

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </div>


                   </div>

                    <form action="<?php echo e(route('gallery.store')); ?>" id="gallery-upload" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

                        <div class="">
                            <input type="file" id="gallery-input" name="galleries[]" class="d-none <?php $__errorArgs = ['galleries'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['galleries.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " multiple>
                                <?php $__errorArgs = ['galleries'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <?php $__errorArgs = ['galleries.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </form>


                </div>


                <div class="text-center mb-4">
                    <button class="btn btn-lg btn-primary " form="post-create">
                        <i class="fas fa-message"></i>
                        Update Post
                    </button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        let coverPreview = document.querySelector("#coverPreview");
        let cover =document.querySelector('#cover');

        coverPreview.addEventListener('click',function(){
            cover.click();

        });

        cover.addEventListener('change',function(){
            let reader = new FileReader();

            reader.onload  = function (){
                coverPreview.src = reader.result;
            };
            reader.readAsDataURL(cover.files[0]);
            // console.log(cover.file);
        });


        let uploadUi = document.querySelector('#upload-ui');
        let galleryInput = document.getElementById('gallery-input');
        let galleryUpload = document.getElementById('gallery-upload');

        uploadUi.addEventListener('click',function (){
            galleryInput.click();
        });

        galleryInput.addEventListener('change',function (){
           galleryUpload.submit();
        });

    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolar/Desktop/MMS IT(Web Development)/Laravel/the-explorer-laravel/resources/views/post/edit.blade.php ENDPATH**/ ?>