<?php $__env->startSection('title'); ?>
    Edit Profile : <?php echo e(env('APP_NAME')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="text-center  mt-5">
                    <img src="<?php echo e(asset(\Illuminate\Support\Facades\Auth::user()->photo)); ?>" class="profile-image" alt="">
                    <br>
                    <button class="btn btn-sm btn-primary" id="edit-photo" style="margin-top: -25px">
                        <i class="fas fa-pencil-alt"></i>
                    </button>
                    <p class="mb-0"><?php echo e(auth()->user()->name); ?></p>
                    <p class="small text-black-50"><?php echo e(auth()->user()->email); ?></p>
                </div>

                <form action="<?php echo e(route('update-profile')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="file" name="photo" value="<?php echo e(old('photo',auth()->user()->photo)); ?>" class="d-none <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="photo" accept="image/jpeg,image/png">
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <div class="form-floating mb-3">
                        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="yourName" value="<?php echo e(old('name',auth()->user()->name)); ?>" placeholder="name@example.com">
                        <label for="yourName">Profile Name</label>

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-floating mb-3">
                        <input disabled type="email" class="form-control " id="floatingInput" value="<?php echo e(auth()->user()->email); ?>" placeholder="name@example.com">
                        <label for="floatingInput">Email address</label>
                    </div>

                    <div class="text-center">
                        <button class="btn btn-lg btn-primary">Update Profile</button>
                    </div>
                </form>

            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        let profileImage = document.querySelector('.profile-image');
        let editPhoto =document.querySelector('#edit-photo');
        let photo = document.getElementById('photo');

        editPhoto.addEventListener('click',function (){
            photo.click();
        })


        // cover.addEventListener('change',function(){
        //     let reader = new FileReader();
        //
        //     reader.onload  = function (){
        //         coverPreview.src = reader.result;
        //     };
        //     reader.readAsDataURL(cover.files[0]);
        //     // console.log(cover.file);
        // });


        photo.addEventListener('change',function (){
            let file = photo.files[0];
            let reader = new FileReader();

            reader.onload = function (){
                profileImage.src = reader.result;
            }
            reader.readAsDataURL(file);
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolar/Desktop/MMS IT(Web Development)/Laravel/the-explorer-laravel/resources/views/profile/edit-profile.blade.php ENDPATH**/ ?>